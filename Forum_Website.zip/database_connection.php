<?php


$server= "localhost";
$user= "deb";
$password = "Debabrata@123";
$database = "php_tutorial";

$con= mysqli_connect($server,$user,$password,$database);

if (!$con){

    echo mysqli_connect_error();
}


?>
