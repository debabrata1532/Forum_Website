

<?php
echo '
<div class="container-fluid bg-dark text-light mb-0">

<p class="text-center">Copyrights 2021 | All rights are reserved </p>

</div>';

?>